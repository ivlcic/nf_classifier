                           Training corpus
                           SETimes.SR 1.0

    Citation, documentation, download, and licence available from
                   http://hdl.handle.net/11356/1200
